import os

# Flask
from flask import Flask, redirect, url_for, request, render_template, Response, jsonify, redirect, current_app, flash

# TensorFlow
import tensorflow as tf

from efficientnet.tfkeras import EfficientNetB6

from werkzeug.utils import secure_filename

import re
import base64

import numpy as np

import cv2



# Declarando la aplicación flask 
app = Flask(__name__)

app.secret_key = "secret key"
app.config['UPLOAD_FOLDER'] = "upload\\"

# Ruta del modelo entrenado 
UPLOAD      = "upload\\"
MODEL_PATH  = 'modelo/melanomaModel.h5'
IMAGE_SIZE  = 512
CROP_SIZE   = 495
SEED        = 1701

# Carga del modelo preentrenado
model = tf.keras.models.load_model(MODEL_PATH)

 
def processImagePredict(filename):

    #image = tf.image.decode_jpeg(image, channels=3)
    current_app.logger.info(UPLOAD  + filename)
    img = cv2.imread(UPLOAD+filename)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    
    current_app.logger.info("imagen antes ["+str(img)+"]")
    img_tensor = tf.convert_to_tensor(img, dtype=tf.float32)
    current_app.logger.info("imagen después ["+str(img_tensor)+"]")
    # Se recorta la imagen si hay dataAugmentation
    image = tf.image.random_crop(img_tensor,[CROP_SIZE,CROP_SIZE,3])
    
    image = tf.cast(image, tf.float32)/ 255.0  
    image = tf.image.resize(image, [IMAGE_SIZE,IMAGE_SIZE])
    image = tf.reshape(image,[1,IMAGE_SIZE,IMAGE_SIZE, 3])
    
    #img_final = tf.expand_dims(img_resized, 0)

    preds = model.predict(image)
    current_app.logger.info("type ["+str(type(preds))+"]")
    current_app.logger.info("Predicciones *"+str(preds[0])+"*")
    #preds = 0
    return preds

@app.route('/', methods=['GET'])
def index():
    # Main page
    current_app.logger.info('Pagina principal')
    return render_template('index.html')

@app.route('/index2', methods=['GET'])
def index2():
    # Main page
    current_app.logger.info('Pagina json')
    return render_template('index2.html')
    

@app.route('/predecir', methods=['GET', 'POST'])
def predict():
    current_app.logger.info('predecir')
    if request.method == 'POST':
        image = request.json
        current_app.logger.info('json')
        
        image_data = re.sub('^data:image/.+;base64,', '', image)
        image_64_decode = base64.b64decode(image_data)
        
        image = tf.image.decode_jpeg(image_64_decode, channels=3)
    
        # Se recorta la imagen si hay dataAugmentation
        image = tf.image.random_crop(image,[CROP_SIZE,CROP_SIZE,3])
        
        image = tf.cast(image, tf.float32)/ 255.0  
        image = tf.image.resize(image, [IMAGE_SIZE,IMAGE_SIZE])
        image = tf.reshape(image, [1,IMAGE_SIZE,IMAGE_SIZE, 3])
        
        current_app.logger.info("[ antes de predecir]")
        preds = model.predict(image)
        current_app.logger.info("*"+str(preds[0][0])+"*")
        
        if preds[0][0] < 0.5:
            return jsonify(result="Benigno", probability=(1-preds[0][0]))
        else:
            return jsonify(result="Maligno", probability=(preds[0][0]))
        
     
    return None
    
@app.route('/', methods=['POST'])
def submitFile():
    current_app.logger.info('predecir')
    if request.method == 'POST':
    
        if 'file' not in request.files:
            #flash('No file part')
            image = request.json
            current_app.logger.info('json')
        
            image_data = re.sub('^data:image/.+;base64,', '', image)
            image_64_decode = base64.b64decode(image_data)
            #current_app.logger.info("["+str(image_64_decode)+"]")
            
            
            
            return redirect('/')
            
        file = request.files['file']
        
        if file.filename == '':
        
            flash('No file selected for uploading')
            return redirect(request.url)

        if file:
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'],filename))
            current_app.logger.info('fichero')
        
            pred = processImagePredict(filename)
            
            flash(str(pred[0][0]))

            flash(filename)
            return redirect('/')

        # Serialize the result, you can add additional fields
        

    return None
    
if __name__ == "__main__":
    app.run()

